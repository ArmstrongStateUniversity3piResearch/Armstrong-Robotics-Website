#include <pololu/3pi.h>
#include "ArmstrongNavigation/ArmstrongNavigation.h"

int main()
{
	// Initialize 3pi sensors
	initialize();
	
	// Move foward
	print("GO!");
	set_motors(20, 20);
	
	// Play music
	while (1)
	{
		play("T216 L8 c4.<gr4<e4.a4b4a#a4g6>e6>g6>a4<fgre4cd<b4.");
		while(is_playing());
	}
}
