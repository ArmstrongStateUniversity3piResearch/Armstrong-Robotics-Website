/*
 * follow_segment.h
 */ 

#ifndef FOLLOW_SEGMENT_H_
#define FOLLOW_SEGMENT_H_

void follow_segment();

#endif /* FOLLOW_SEGMENT_H_ */
